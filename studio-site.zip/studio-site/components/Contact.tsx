import { site } from "@/lib/content";

export function Contact() {
  return (
    <section className="contact" id="contact" aria-labelledby="contact-title">
      <h2 className="contact__title" id="contact-title">
        <span className="contact__line contact__line--white">Got a season</span>
        <span className="contact__line contact__line--pink">coming up?</span>
      </h2>
      <p className="contact__text">
        Tell us about your team, your timeline and what you want to achieve.
      </p>
      <a className="btn btn--solid" href={`mailto:${site.email}?subject=New%20project%20enquiry`}>
        Start a project
      </a>
      <a className="contact__mail" href={`mailto:${site.email}`}>
        {site.email}
      </a>
    </section>
  );
}
