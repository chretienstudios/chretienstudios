import { Poster } from "./Poster";
import { Underline } from "./Underline";
import { services, type Service, type Tone } from "@/lib/content";

const collageTiles: { tone: Tone; number: string }[] = [
  { tone: "ultra", number: "30" },
  { tone: "crimson", number: "11" },
  { tone: "volt", number: "47" },
  { tone: "dusk", number: "09" },
  { tone: "ember", number: "26" },
  { tone: "ultra", number: "15" },
];

function Screen() {
  return (
    <div className="screen">
      <div className="screen__bar" />
      <div className="screen__art" />
      <div className="screen__line" />
      <div className="screen__line screen__line--short" />
    </div>
  );
}

function Visual({ visual }: { visual: Service["visual"] }) {
  if (visual.src) {
    return <Poster tone={visual.tone} src={visual.src} alt={visual.alt} className="visual" />;
  }
  if (visual.kind === "collage") {
    return (
      <div className="visual visual--collage" aria-hidden="true">
        {collageTiles.map((tile, i) => (
          <Poster key={i} tone={tile.tone} number={tile.number} className="collage__tile" />
        ))}
      </div>
    );
  }
  return (
    <Poster tone={visual.tone} number={visual.number} className="visual" >
      <div className="phone phone--a" aria-hidden="true">
        <Screen />
      </div>
      <div className="phone phone--b" aria-hidden="true">
        <Screen />
      </div>
    </Poster>
  );
}

export function Services() {
  return (
    <section className="services" id="services" aria-labelledby="services-title">
      <h2 className="title" id="services-title">
        What we do{" "}
        <span className="title__mark">
          for you
          <Underline />
        </span>
      </h2>

      <div className="services__grid">
        {services.map((s) => (
          <article className="service" key={s.id}>
            <Visual visual={s.visual} />
            <div className="service__body">
              <h3 className="service__name">
                {s.nameTop}
                <span>{s.nameAccent}</span>
              </h3>
              <p className="service__lead">{s.lead}</p>
              <p className="service__text">{s.text}</p>
              <p className="service__inc">Includes:</p>
              <ul className="service__list">
                {s.includes.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
