import { Poster } from "./Poster";
import { hero } from "@/lib/content";

export function Hero() {
  return (
    <section className="hero" id="top">
      <div className="hero__lights" aria-hidden="true" />
      <div className="hero__posters" aria-hidden="true">
        {hero.posters.map((p, i) => (
          <Poster
            key={i}
            tone={p.tone}
            number={p.number}
            src={p.src}
            className={`hero__poster hero__poster--${i + 1}`}
          />
        ))}
      </div>
      <div className="hero__fade" aria-hidden="true" />
      <div className="hero__grain" aria-hidden="true" />

      <div className="hero__copy">
        <h1 className="hero__title">
          <span className="hero__line hero__line--white">
            <span>{hero.lineOne}</span>
          </span>
          <span className="hero__line hero__line--pink">
            <span>{hero.lineTwo}</span>
          </span>
        </h1>
        <p className="hero__sub">{hero.sub}</p>
        <div className="hero__actions">
          <a className="btn btn--solid" href="#work">
            See the work
          </a>
          <a className="btn btn--ghost" href="#contact">
            Start a project
          </a>
        </div>
      </div>
    </section>
  );
}
