import { site } from "@/lib/content";

export function Footer() {
  return (
    <footer className="footer">
      <a className="wordmark" href="#top" aria-label="Back to top">
        <strong>{site.wordmark.strong}</strong>
        <span>{site.wordmark.light}</span>
      </a>
      <ul className="footer__social">
        {site.socials.map((s) => (
          <li key={s.label}>
            <a href={s.href} target="_blank" rel="noopener noreferrer">
              {s.label}
            </a>
          </li>
        ))}
      </ul>
      <p className="footer__legal">
        © {new Date().getFullYear()} {site.wordmark.strong}
        {site.wordmark.light}
      </p>
    </footer>
  );
}
