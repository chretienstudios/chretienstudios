import type { CSSProperties, ReactNode } from "react";
import type { Tone } from "@/lib/content";

type PosterProps = {
  tone: Tone;
  number?: string;
  src?: string;
  alt?: string;
  className?: string;
  style?: CSSProperties;
  children?: ReactNode;
};

// A duotone, halftone "poster". With no `src` it shows a jersey number as
// stand-in artwork; with a `src` it shows your image through the same duotone.
export function Poster({ tone, number, src, alt = "", className = "", style, children }: PosterProps) {
  return (
    <div className={`poster poster--${tone} ${className}`.trim()} style={style}>
      {src ? (
        <img className="poster__img" src={src} alt={alt} loading="lazy" />
      ) : number ? (
        <span className="poster__num" aria-hidden="true">
          {number}
        </span>
      ) : null}
      {children}
    </div>
  );
}
