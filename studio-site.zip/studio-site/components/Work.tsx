import { Poster } from "./Poster";
import { work } from "@/lib/content";

export function Work() {
  return (
    <section className="work" id="work" aria-labelledby="work-title">
      <div className="wrap">
        <h2 className="title title--left" id="work-title">
          Selected work
        </h2>
        <ul className="work__grid">
          {work.map((w) => (
            <li className="tile" key={w.title}>
              <Poster tone={w.tone} number={w.number} src={w.src} alt={w.title} className="tile__poster">
                <div className="tile__cap">
                  <p className="tile__title">{w.title}</p>
                  <p className="tile__cat">{w.category}</p>
                </div>
              </Poster>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
