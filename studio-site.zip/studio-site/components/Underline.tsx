export function Underline() {
  return (
    <svg
      className="underline"
      viewBox="0 0 400 24"
      preserveAspectRatio="none"
      aria-hidden="true"
      focusable="false"
    >
      <path
        d="M4 15 C 70 6, 150 20, 230 11 S 350 9, 396 13"
        fill="none"
        stroke="currentColor"
        strokeWidth="5"
        strokeLinecap="round"
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  );
}
