import { steps } from "@/lib/content";

export function Process() {
  return (
    <section className="process" id="process" aria-labelledby="process-title">
      <div className="wrap">
        <h2 className="title title--left" id="process-title">
          How it works
        </h2>
        <ol className="process__list">
          {steps.map((s, i) => (
            <li className="step" key={s.title}>
              <span className="step__num" aria-hidden="true">
                {i + 1}
              </span>
              <h3 className="step__title">{s.title}</h3>
              <p className="step__text">{s.text}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
