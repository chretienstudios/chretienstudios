"use client";

import { useEffect, useRef, useState } from "react";
import { site } from "@/lib/content";

export function Header() {
  const [open, setOpen] = useState(false);
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open]);

  const close = () => setOpen(false);

  return (
    <header className="site-header">
      <a className="wordmark" href="#top" aria-label={`${site.wordmark.strong}${site.wordmark.light}, back to top`}>
        <strong>{site.wordmark.strong}</strong>
        <span>{site.wordmark.light}</span>
      </a>

      <div className="header-right">
        <nav className="nav" aria-label="Primary">
          {site.nav.map((link) => (
            <a key={link.href} href={link.href}>
              {link.label}
            </a>
          ))}
        </nav>
        <a className="header-cta" href="#contact">
          Contact us
        </a>
      </div>

      <button
        className="menu-toggle"
        type="button"
        aria-expanded={open}
        aria-controls="mobile-menu"
        onClick={() => setOpen(true)}
      >
        Menu
      </button>

      <div id="mobile-menu" className="menu" role="dialog" aria-modal="true" aria-label="Menu" hidden={!open}>
        <button ref={closeRef} className="menu__close" type="button" onClick={close}>
          Close
        </button>
        <nav className="menu__links" aria-label="Mobile">
          {site.nav.map((link) => (
            <a key={link.href} href={link.href} onClick={close}>
              {link.label}
            </a>
          ))}
          <a href="#contact" onClick={close}>
            Contact us
          </a>
        </nav>
      </div>
    </header>
  );
}
