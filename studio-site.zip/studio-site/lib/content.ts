// Everything on the page comes from this file. Edit the text, links and
// project tiles here. To use real artwork, drop images in /public/work and
// set `src` (for example "/work/club-rebrand.jpg") on any poster or tile.

export type Tone = "ember" | "ultra" | "volt" | "crimson" | "dusk";

export const site = {
  wordmark: { strong: "chrétien", light: "studios" },
  title: "chrétienstudios | Sports design for clubs, athletes and leagues",
  description:
    "Brand identities, match-day graphics and in-stadium creative for clubs, leagues and athletes.",
  email: "chretienstudios@gmail.com",
  nav: [
    { label: "Work", href: "#work" },
    { label: "Services", href: "#services" },
    { label: "Process", href: "#process" },
  ],
  socials: [
    { label: "Instagram", href: "https://www.instagram.com/chretienstudios/" },
  ],
};

export const hero = {
  lineOne: "Brands built for",
  lineTwo: "Game day",
  sub: "Brand identities, match-day graphics and in-stadium creative for clubs, leagues and athletes.",
  posters: [
    { tone: "crimson", number: "26" },
    { tone: "ultra", number: "30" },
    { tone: "ember", number: "11" },
    { tone: "volt", number: "47" },
    { tone: "dusk", number: "09" },
  ] as { tone: Tone; number: string; src?: string }[],
};

export type Service = {
  id: string;
  nameTop: string;
  nameAccent: string;
  lead: string;
  text: string;
  includes: string[];
  visual: {
    kind: "phones" | "collage";
    tone: Tone;
    number?: string;
    src?: string;
    alt?: string;
  };
};

export const services: Service[] = [
  {
    id: "brand",
    nameTop: "Full brand &",
    nameAccent: "creative refresh",
    lead: "For teams that want to stand out from the rest.",
    text: "Whether you need fresh creative for the content you already have or a new identity built from scratch, we shape a look your fans recognise instantly.",
    includes: [
      "Logo and identity systems",
      "Kit and merchandise graphics",
      "Brand guidelines",
      "Social media template suite",
    ],
    visual: { kind: "phones", tone: "ember", number: "26" },
  },
  {
    id: "reactive",
    nameTop: "Bespoke",
    nameAccent: "reactive graphics",
    lead: "Be first to post.",
    text: "Systems set up in advance mean high-engagement artwork reaches your channels minutes after the final whistle.",
    includes: [
      "High-engagement hero artwork",
      "On-demand, fan-focused content",
      "Match-day and result graphics",
      "Player and staff announcements",
    ],
    visual: { kind: "collage", tone: "ultra" },
  },
  {
    id: "stadium",
    nameTop: "Results-focused",
    nameAccent: "stadium creative",
    lead: "Give the crowd something to look at.",
    text: "Full in-stadium creative that lifts sponsor visibility and match-day revenue for your club.",
    includes: [
      "LED signage animations",
      "Big-screen and concourse content",
      "Sponsor and partner activations",
      "Season launch and event packages",
    ],
    visual: { kind: "phones", tone: "volt", number: "47" },
  },
];

export const work: { title: string; category: string; tone: Tone; number: string; src?: string }[] = [
  { title: "Club rebrand", category: "Identity", tone: "ember", number: "26" },
  { title: "Match-day series", category: "Reactive graphics", tone: "ultra", number: "30" },
  { title: "Player campaign", category: "Athlete profile", tone: "crimson", number: "11" },
  { title: "Stadium LED package", category: "Stadium creative", tone: "volt", number: "47" },
  { title: "Season launch", category: "Campaign", tone: "dusk", number: "09" },
  { title: "Kit reveal", category: "Merchandise", tone: "ember", number: "15" },
  { title: "Sponsor activation", category: "Partnerships", tone: "ultra", number: "08" },
];

export const steps = [
  {
    title: "Brief",
    text: "We learn your club, your audience and your sponsors, then agree goals, scope and timeline.",
  },
  {
    title: "Concepts",
    text: "You see routes for the look and feel before any production begins.",
  },
  {
    title: "Production",
    text: "We build the artwork, templates and animations, with clear rounds for your feedback.",
  },
  {
    title: "Season support",
    text: "Files, guidelines and on-call design keep everything consistent all year.",
  },
];
