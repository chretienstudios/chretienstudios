# Design studio landing page

Next.js (App Router, TypeScript) landing page for a design studio. No extra UI
libraries. Fonts are Unbounded (headings) and Hanken Grotesk (body), loaded with
`next/font`.

## Run it

```bash
npm install
npm run dev      # http://localhost:3000
npm run build    # production build check
```

## Make it yours

All copy, links and project tiles live in `lib/content.ts`:

- `site`: studio name, email, nav links, social links
- `hero`: headline, subline and the five hero posters
- `services`: the three service columns
- `work`: the project tiles
- `steps`: the process section

The artwork starts as duotone placeholder posters. To use real images, put them
in `public/work/` and set `src: "/work/your-image.jpg"` on any hero poster,
service visual or work tile. Images are tinted with the same duotone treatment,
so use high-contrast photos or cut-outs.

Colours and type sizes are the variables at the top of `app/globals.css`.

## Deploy to Vercel

Option A, from GitHub:
1. Push this folder to a new GitHub repo.
2. Go to https://vercel.com/new, import the repo and click Deploy. No settings
   need changing; Vercel detects Next.js.

Option B, from the terminal:

```bash
npx vercel        # first run links the project and creates a preview
npx vercel --prod # ship to production
```
